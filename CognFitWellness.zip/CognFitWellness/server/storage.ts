import { users, type User, type InsertUser } from "@shared/schema";
import { 
  type StudySession, 
  type InsertStudySession, 
  type ProcessFitness, 
  type InsertProcessFitness, 
  type YogaSession, 
  type InsertYogaSession 
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Storage interface
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Study session methods
  getStudySessionsByUserId(userId: number): Promise<StudySession[]>;
  getStudySession(id: number): Promise<StudySession | undefined>;
  createStudySession(session: InsertStudySession): Promise<StudySession>;
  updateStudySession(id: number, userId: number, data: Partial<StudySession>): Promise<StudySession | undefined>;
  
  // Process fitness methods
  getProcessFitnessByUserId(userId: number): Promise<ProcessFitness[]>;
  getProcessFitness(id: number): Promise<ProcessFitness | undefined>;
  createProcessFitness(fitness: InsertProcessFitness): Promise<ProcessFitness>;
  updateProcessFitness(id: number, userId: number, data: Partial<ProcessFitness>): Promise<ProcessFitness | undefined>;
  
  // Yoga session methods
  getYogaSessionsByUserId(userId: number): Promise<YogaSession[]>;
  getYogaSession(id: number): Promise<YogaSession | undefined>;
  createYogaSession(session: InsertYogaSession): Promise<YogaSession>;
  updateYogaSession(id: number, userId: number, data: Partial<YogaSession>): Promise<YogaSession | undefined>;
  
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private studySessions: Map<number, StudySession>;
  private processFitnesses: Map<number, ProcessFitness>;
  private yogaSessions: Map<number, YogaSession>;
  
  sessionStore: session.SessionStore;
  currentUserId: number;
  currentStudySessionId: number;
  currentProcessFitnessId: number;
  currentYogaSessionId: number;

  constructor() {
    this.users = new Map();
    this.studySessions = new Map();
    this.processFitnesses = new Map();
    this.yogaSessions = new Map();
    
    this.currentUserId = 1;
    this.currentStudySessionId = 1;
    this.currentProcessFitnessId = 1;
    this.currentYogaSessionId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
    
    // Add some initial data for demo purposes
    this._seedInitialData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Study session methods
  async getStudySessionsByUserId(userId: number): Promise<StudySession[]> {
    return Array.from(this.studySessions.values()).filter(
      (session) => session.userId === userId
    );
  }
  
  async getStudySession(id: number): Promise<StudySession | undefined> {
    return this.studySessions.get(id);
  }
  
  async createStudySession(insertSession: InsertStudySession): Promise<StudySession> {
    const id = this.currentStudySessionId++;
    const createdAt = new Date();
    const session: StudySession = { ...insertSession, id, createdAt };
    this.studySessions.set(id, session);
    return session;
  }
  
  async updateStudySession(id: number, userId: number, data: Partial<StudySession>): Promise<StudySession | undefined> {
    const session = this.studySessions.get(id);
    if (!session || session.userId !== userId) {
      return undefined;
    }
    
    const updatedSession = { ...session, ...data };
    this.studySessions.set(id, updatedSession);
    return updatedSession;
  }
  
  // Process fitness methods
  async getProcessFitnessByUserId(userId: number): Promise<ProcessFitness[]> {
    return Array.from(this.processFitnesses.values()).filter(
      (fitness) => fitness.userId === userId
    );
  }
  
  async getProcessFitness(id: number): Promise<ProcessFitness | undefined> {
    return this.processFitnesses.get(id);
  }
  
  async createProcessFitness(insertFitness: InsertProcessFitness): Promise<ProcessFitness> {
    const id = this.currentProcessFitnessId++;
    const createdAt = new Date();
    const fitness: ProcessFitness = { ...insertFitness, id, createdAt };
    this.processFitnesses.set(id, fitness);
    return fitness;
  }
  
  async updateProcessFitness(id: number, userId: number, data: Partial<ProcessFitness>): Promise<ProcessFitness | undefined> {
    const fitness = this.processFitnesses.get(id);
    if (!fitness || fitness.userId !== userId) {
      return undefined;
    }
    
    const updatedFitness = { ...fitness, ...data };
    this.processFitnesses.set(id, updatedFitness);
    return updatedFitness;
  }
  
  // Yoga session methods
  async getYogaSessionsByUserId(userId: number): Promise<YogaSession[]> {
    return Array.from(this.yogaSessions.values()).filter(
      (session) => session.userId === userId
    );
  }
  
  async getYogaSession(id: number): Promise<YogaSession | undefined> {
    return this.yogaSessions.get(id);
  }
  
  async createYogaSession(insertSession: InsertYogaSession): Promise<YogaSession> {
    const id = this.currentYogaSessionId++;
    const createdAt = new Date();
    const session: YogaSession = { ...insertSession, id, createdAt };
    this.yogaSessions.set(id, session);
    return session;
  }
  
  async updateYogaSession(id: number, userId: number, data: Partial<YogaSession>): Promise<YogaSession | undefined> {
    const session = this.yogaSessions.get(id);
    if (!session || session.userId !== userId) {
      return undefined;
    }
    
    const updatedSession = { ...session, ...data };
    this.yogaSessions.set(id, updatedSession);
    return updatedSession;
  }
  
  // Seed initial data for demo
  private _seedInitialData() {
    // Will be populated when users register
  }
}

export const storage = new MemStorage();
