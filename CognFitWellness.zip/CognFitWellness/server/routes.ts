import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertStudySessionSchema, 
  insertProcessFitnessSchema, 
  insertYogaSessionSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Sets up auth routes: /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Study Sessions API
  app.get("/api/study-sessions", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
      const userId = req.user!.id;
      const sessions = await storage.getStudySessionsByUserId(userId);
      res.json(sessions);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/study-sessions", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
      
      const parsedData = insertStudySessionSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const session = await storage.createStudySession(parsedData);
      res.status(201).json(session);
    } catch (error) {
      next(error);
    }
  });

  app.patch("/api/study-sessions/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
      
      const sessionId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      const updatedSession = await storage.updateStudySession(sessionId, userId, req.body);
      if (!updatedSession) {
        return res.status(404).send("Session not found");
      }
      
      res.json(updatedSession);
    } catch (error) {
      next(error);
    }
  });

  // Process Fitness API
  app.get("/api/process-fitness", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
      const userId = req.user!.id;
      const processFitness = await storage.getProcessFitnessByUserId(userId);
      res.json(processFitness);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/process-fitness", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
      
      const parsedData = insertProcessFitnessSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const processFitness = await storage.createProcessFitness(parsedData);
      res.status(201).json(processFitness);
    } catch (error) {
      next(error);
    }
  });

  app.patch("/api/process-fitness/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
      
      const fitnessId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      const updatedFitness = await storage.updateProcessFitness(fitnessId, userId, req.body);
      if (!updatedFitness) {
        return res.status(404).send("Process fitness not found");
      }
      
      res.json(updatedFitness);
    } catch (error) {
      next(error);
    }
  });

  // Yoga Sessions API
  app.get("/api/yoga-sessions", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
      const userId = req.user!.id;
      const yogaSessions = await storage.getYogaSessionsByUserId(userId);
      res.json(yogaSessions);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/yoga-sessions", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
      
      const parsedData = insertYogaSessionSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const yogaSession = await storage.createYogaSession(parsedData);
      res.status(201).json(yogaSession);
    } catch (error) {
      next(error);
    }
  });

  app.patch("/api/yoga-sessions/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
      
      const sessionId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      const updatedSession = await storage.updateYogaSession(sessionId, userId, req.body);
      if (!updatedSession) {
        return res.status(404).send("Yoga session not found");
      }
      
      res.json(updatedSession);
    } catch (error) {
      next(error);
    }
  });

  // Get stats for dashboard
  app.get("/api/stats", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
      const userId = req.user!.id;
      
      const studySessions = await storage.getStudySessionsByUserId(userId);
      const processFitness = await storage.getProcessFitnessByUserId(userId);
      const yogaSessions = await storage.getYogaSessionsByUserId(userId);
      
      // Calculate total study time in hours
      const totalStudyTime = studySessions.reduce((total, session) => {
        return total + (session.duration || 0);
      }, 0) / 60; // Convert minutes to hours
      
      // Count focus sessions, process fitness, and yoga sessions
      const focusSessions = studySessions.length;
      const processCount = processFitness.filter(p => p.completed).length;
      const yogaCount = yogaSessions.filter(y => y.completed).length;
      
      // Get recent activities (combined and sorted)
      const recentActivities = [
        ...studySessions.map(s => ({ 
          type: 'study',
          title: s.title,
          description: `${s.duration} min study session`,
          createdAt: s.createdAt,
          progress: s.completed ? 100 : 0,
        })),
        ...processFitness.map(p => ({
          type: 'fitness',
          title: p.title,
          description: p.description || '',
          createdAt: p.createdAt,
          completed: p.completed,
        })),
        ...yogaSessions.map(y => ({
          type: 'yoga',
          title: y.sessionName,
          description: `${y.duration} min yoga session`,
          createdAt: y.createdAt,
          completed: y.completed,
        }))
      ].sort((a, b) => {
        return new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime();
      }).slice(0, 5);
      
      res.json({
        studyTime: totalStudyTime.toFixed(1),
        focusSessions,
        processCount,
        yogaCount,
        recentActivities
      });
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
