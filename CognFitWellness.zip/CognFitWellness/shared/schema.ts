import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  email: text("email"),
});

export const studySessions = pgTable("study_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  duration: integer("duration").notNull(), // in minutes
  subject: text("subject"),
  notes: text("notes"),
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const processFitness = pgTable("process_fitness", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const yogaSessions = pgTable("yoga_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  sessionName: text("session_name").notNull(),
  duration: integer("duration").notNull(), // in minutes
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas for database tables
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  firstName: true,
  lastName: true,
  email: true,
});

export const insertStudySessionSchema = createInsertSchema(studySessions).pick({
  userId: true,
  title: true,
  duration: true,
  subject: true,
  notes: true,
  completed: true,
});

export const insertProcessFitnessSchema = createInsertSchema(processFitness).pick({
  userId: true,
  title: true,
  description: true,
  completed: true,
});

export const insertYogaSessionSchema = createInsertSchema(yogaSessions).pick({
  userId: true,
  sessionName: true,
  duration: true,
  completed: true,
});

// Types for database models
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertStudySession = z.infer<typeof insertStudySessionSchema>;
export type StudySession = typeof studySessions.$inferSelect;

export type InsertProcessFitness = z.infer<typeof insertProcessFitnessSchema>;
export type ProcessFitness = typeof processFitness.$inferSelect;

export type InsertYogaSession = z.infer<typeof insertYogaSessionSchema>;
export type YogaSession = typeof yogaSessions.$inferSelect;

// Login data type
export type LoginData = Pick<InsertUser, "username" | "password">;
