import { useQuery } from "@tanstack/react-query";
import { Loader2, PlayCircle } from "lucide-react";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function YogaSessionsPage() {
  const { data: yogaSessions, isLoading } = useQuery({
    queryKey: ["/api/yoga-sessions"],
  });

  // Yoga sessions data
  const sessions = [
    {
      id: 1,
      title: "Focus & Clarity",
      duration: 20,
      level: "Beginner",
      description: "Improve concentration and mental clarity with gentle poses and breathwork",
      benefits: ["Enhanced focus", "Reduced anxiety", "Mental clarity"],
      background: "bg-gradient-to-r from-blue-500 to-indigo-600"
    },
    {
      id: 2, 
      title: "Stress Relief",
      duration: 30,
      level: "Beginner",
      description: "Relieve tension and calm your mind with relaxing poses and deep breathing",
      benefits: ["Stress reduction", "Relaxed body", "Calm mind"],
      background: "bg-gradient-to-r from-green-400 to-emerald-500"
    },
    {
      id: 3,
      title: "Energy Boost",
      duration: 25,
      level: "Intermediate",
      description: "Energize your body and mind with dynamic poses and invigorating breathwork",
      benefits: ["Increased energy", "Mental alertness", "Physical activation"],
      background: "bg-gradient-to-r from-orange-400 to-pink-500"
    },
    {
      id: 4,
      title: "Mind-Body Balance",
      duration: 40,
      level: "Intermediate",
      description: "Harmonize your physical and mental aspects with balanced practice",
      benefits: ["Improved balance", "Mind-body connection", "Centered awareness"],
      background: "bg-gradient-to-r from-purple-500 to-pink-500"
    },
    {
      id: 5,
      title: "Pre-Study Preparation",
      duration: 15,
      level: "Beginner",
      description: "Quick session to prepare your mind for effective studying",
      benefits: ["Mental preparation", "Improved focus", "Reduced pre-study anxiety"],
      background: "bg-gradient-to-r from-cyan-500 to-blue-500"
    },
    {
      id: 6,
      title: "Deep Relaxation",
      duration: 45,
      level: "All Levels",
      description: "Deeply relax your body and mind with gentle poses and extended savasana",
      benefits: ["Deep relaxation", "Stress release", "Improved sleep quality"],
      background: "bg-gradient-to-r from-indigo-500 to-purple-600"
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 pb-16 md:pb-0">
          <div className="p-6">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-neutral-800">Yoga Sessions</h2>
              <p className="text-neutral-500">Practice pre-recorded yoga sessions designed for students</p>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sessions.map((session) => (
                  <Card key={session.id} className="overflow-hidden">
                    <div className={`h-40 relative ${session.background}`}>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Button variant="ghost" size="icon" className="rounded-full bg-white/20 hover:bg-white/30">
                          <PlayCircle className="h-12 w-12 text-white" />
                        </Button>
                      </div>
                    </div>
                    <CardContent className="p-5">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-lg">{session.title}</h3>
                        <Badge variant="outline">{session.level}</Badge>
                      </div>
                      <div className="flex items-center text-sm text-neutral-500 mb-3">
                        <span className="material-icons text-sm mr-1">schedule</span>
                        <span>{session.duration} minutes</span>
                      </div>
                      <p className="text-neutral-600 text-sm mb-4">{session.description}</p>
                      <div>
                        <h4 className="text-sm font-medium mb-2">Benefits:</h4>
                        <div className="flex flex-wrap gap-2">
                          {session.benefits.map((benefit, index) => (
                            <span 
                              key={index} 
                              className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full"
                            >
                              {benefit}
                            </span>
                          ))}
                        </div>
                      </div>
                      <Button className="w-full mt-4">Start Session</Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
