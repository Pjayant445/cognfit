import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { format } from "date-fns";
import { useEffect } from "react";
import { useLocation } from "wouter";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import StatsCard from "@/components/dashboard/stats-card";
import ProgressChart from "@/components/dashboard/progress-chart";
import ActivityItem from "@/components/dashboard/activity-item";
import { useAuth } from "@/hooks/use-auth";

export default function DashboardPage() {
  const { user, isLoading: isLoadingAuth } = useAuth();
  const [_, setLocation] = useLocation();
  
  // Redirect to auth if not logged in
  useEffect(() => {
    if (!isLoadingAuth && !user) {
      setLocation("/auth");
    }
  }, [user, isLoadingAuth, setLocation]);
  
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/stats"],
    enabled: !!user,
  });

  const currentDate = format(new Date(), "EEEE, MMMM d, yyyy");

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 pb-16 md:pb-0">
          <div className="p-6">
            {/* Welcome & Date */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-neutral-800">
                Welcome back, {user?.firstName || user?.username}!
              </h2>
              <p className="text-neutral-500">{currentDate}</p>
            </div>

            {isLoadingAuth || isLoadingStats ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <>
                {/* Stats Overview */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  <StatsCard
                    title="Study Time"
                    value={`${stats?.studyTime || "0"}h`}
                    icon="schedule"
                    iconBgColor="bg-primary/10"
                    iconColor="text-primary"
                    trend={+2.5}
                    trendLabel="from last week"
                  />
                  
                  <StatsCard
                    title="Focus Sessions"
                    value={stats?.focusSessions || "0"}
                    icon="psychology"
                    iconBgColor="bg-secondary/10"
                    iconColor="text-secondary"
                    trend={+2}
                    trendLabel="from last week"
                  />
                  
                  <StatsCard
                    title="Process Fitness"
                    value={stats?.processCount || "0"}
                    icon="fitness_center"
                    iconBgColor="bg-primary/10"
                    iconColor="text-primary"
                    trend={-1}
                    trendLabel="from last week"
                    trendDirection="down"
                  />
                  
                  <StatsCard
                    title="Yoga Sessions"
                    value={stats?.yogaCount || "0"}
                    icon="self_improvement"
                    iconBgColor="bg-secondary/10"
                    iconColor="text-secondary"
                    trend={+1}
                    trendLabel="from last week"
                  />
                </div>

                {/* Weekly Progress Chart */}
                <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg font-bold text-neutral-800">Weekly Progress</h3>
                    <div className="flex space-x-2">
                      <button className="px-3 py-1 text-sm bg-primary/10 text-primary rounded-md">Study</button>
                      <button className="px-3 py-1 text-sm bg-neutral-100 text-neutral-600 rounded-md">Fitness</button>
                      <button className="px-3 py-1 text-sm bg-neutral-100 text-neutral-600 rounded-md">Yoga</button>
                    </div>
                  </div>
                  <ProgressChart />
                </div>

                {/* Recent Activity & Process Fitness */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Recent Activities */}
                  <div className="col-span-1 lg:col-span-2">
                    <h3 className="text-lg font-bold text-neutral-800 mb-4">Recent Activities</h3>
                    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                      <ul className="divide-y divide-neutral-200">
                        {stats?.recentActivities?.length > 0 ? (
                          stats.recentActivities.map((activity, index) => (
                            <ActivityItem 
                              key={index}
                              activity={activity} 
                            />
                          ))
                        ) : (
                          <li className="p-4 text-center text-neutral-500">
                            No recent activities
                          </li>
                        )}
                      </ul>
                      <div className="bg-neutral-50 p-3 text-center">
                        <button className="text-primary text-sm font-medium hover:underline">
                          View All Activities
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Recommended Process Fitness */}
                  <div className="col-span-1">
                    <h3 className="text-lg font-bold text-neutral-800 mb-4">Recommended For You</h3>
                    <div className="bg-white rounded-lg shadow-sm">
                      <div className="p-4 border-b border-neutral-200">
                        <h4 className="font-medium text-neutral-800">Process Fitness</h4>
                      </div>
                      <div className="p-4">
                        <div className="space-y-4">
                          <div className="flex items-center p-3 bg-neutral-50 rounded-lg hover:bg-neutral-100 cursor-pointer">
                            <div className="p-2 bg-primary/10 rounded-full mr-3">
                              <span className="material-icons text-primary">psychology</span>
                            </div>
                            <div>
                              <h5 className="font-medium text-neutral-700">Mind Mapping</h5>
                              <p className="text-xs text-neutral-500">Organize complex ideas visually</p>
                            </div>
                          </div>
                          <div className="flex items-center p-3 bg-neutral-50 rounded-lg hover:bg-neutral-100 cursor-pointer">
                            <div className="p-2 bg-primary/10 rounded-full mr-3">
                              <span className="material-icons text-primary">timer</span>
                            </div>
                            <div>
                              <h5 className="font-medium text-neutral-700">Time Blocking</h5>
                              <p className="text-xs text-neutral-500">Schedule your study sessions</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="p-4 border-t border-neutral-200">
                        <h4 className="font-medium text-neutral-800">Yoga Sessions</h4>
                      </div>
                      <div className="p-4">
                        <div className="space-y-4">
                          <div className="relative rounded-lg overflow-hidden">
                            <div className="w-full h-32 bg-gradient-to-r from-primary to-secondary"></div>
                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                              <div className="p-3 text-white">
                                <h5 className="font-medium">Focus & Clarity</h5>
                                <p className="text-xs opacity-80">20 min • Beginner</p>
                              </div>
                            </div>
                            <div className="absolute top-2 right-2 bg-black/50 rounded-full p-1">
                              <span className="material-icons text-white text-sm">play_arrow</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
