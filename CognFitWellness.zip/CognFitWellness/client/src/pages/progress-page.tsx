import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  BarChart, 
  Bar, 
  Legend, 
  PieChart, 
  Pie, 
  Cell 
} from "recharts";

// Mock data for the charts
const weeklyData = [
  { day: "Mon", study: 3, fitness: 1, yoga: 0 },
  { day: "Tue", study: 2, fitness: 0, yoga: 1 },
  { day: "Wed", study: 5, fitness: 2, yoga: 1 },
  { day: "Thu", study: 4, fitness: 1, yoga: 0 },
  { day: "Fri", study: 1, fitness: 1, yoga: 0 },
  { day: "Sat", study: 6, fitness: 1, yoga: 1 },
  { day: "Sun", study: 1, fitness: 0, yoga: 0 },
];

const monthlyProgress = [
  { name: "Week 1", study: 18, fitness: 4, yoga: 2 },
  { name: "Week 2", study: 22, fitness: 6, yoga: 3 },
  { name: "Week 3", study: 17, fitness: 5, yoga: 2 },
  { name: "Week 4", study: 25, fitness: 7, yoga: 4 },
];

const completionData = [
  { name: "Completed", value: 67 },
  { name: "Remaining", value: 33 },
];

const COLORS = ["#5D69F4", "#dddddd"];

export default function ProgressPage() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/stats"],
  });

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 pb-16 md:pb-0">
          <div className="p-6">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-neutral-800">Progress Analytics</h2>
              <p className="text-neutral-500">Track your study, fitness, and yoga progress</p>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <Tabs defaultValue="weekly" className="w-full">
                <TabsList className="mb-8">
                  <TabsTrigger value="weekly">Weekly</TabsTrigger>
                  <TabsTrigger value="monthly">Monthly</TabsTrigger>
                  <TabsTrigger value="summary">Summary</TabsTrigger>
                </TabsList>
                
                <TabsContent value="weekly">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <Card className="lg:col-span-2">
                      <CardHeader>
                        <CardTitle>Weekly Activity</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <AreaChart
                              data={weeklyData}
                              margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="day" />
                              <YAxis />
                              <Tooltip />
                              <Area 
                                type="monotone" 
                                dataKey="study" 
                                stackId="1" 
                                stroke="#5D69F4" 
                                fill="#5D69F4" 
                              />
                              <Area 
                                type="monotone" 
                                dataKey="fitness" 
                                stackId="1" 
                                stroke="#39D98A" 
                                fill="#39D98A" 
                              />
                              <Area 
                                type="monotone" 
                                dataKey="yoga" 
                                stackId="1" 
                                stroke="#FFAA15" 
                                fill="#FFAA15" 
                              />
                            </AreaChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Weekly Goals</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-6">
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm font-medium">Study Hours</span>
                              <span className="text-sm font-medium">22/25 hours</span>
                            </div>
                            <Progress value={88} className="h-2" />
                          </div>
                          
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm font-medium">Process Fitness</span>
                              <span className="text-sm font-medium">6/10 sessions</span>
                            </div>
                            <Progress value={60} className="h-2" />
                          </div>
                          
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm font-medium">Yoga Sessions</span>
                              <span className="text-sm font-medium">3/5 sessions</span>
                            </div>
                            <Progress value={60} className="h-2" />
                          </div>
                          
                          <div className="pt-4 border-t">
                            <h4 className="text-sm font-medium mb-3">Time Distribution</h4>
                            <div className="h-48">
                              <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                  <Pie
                                    data={completionData}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={80}
                                    fill="#8884d8"
                                    paddingAngle={3}
                                    dataKey="value"
                                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                  >
                                    {completionData.map((entry, index) => (
                                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                  </Pie>
                                  <Tooltip />
                                </PieChart>
                              </ResponsiveContainer>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
                
                <TabsContent value="monthly">
                  <div className="grid grid-cols-1 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Monthly Progress</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart
                              width={500}
                              height={300}
                              data={monthlyProgress}
                              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" />
                              <YAxis />
                              <Tooltip />
                              <Legend />
                              <Bar dataKey="study" fill="#5D69F4" name="Study Hours" />
                              <Bar dataKey="fitness" fill="#39D98A" name="Process Fitness" />
                              <Bar dataKey="yoga" fill="#FFAA15" name="Yoga Sessions" />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
                
                <TabsContent value="summary">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle>Total Study Time</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold">{stats?.studyTime || "0"}h</div>
                        <p className="text-neutral-500 text-sm mt-1">Total hours tracked</p>
                        
                        <div className="mt-6">
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium">Monthly Goal</span>
                            <span className="text-sm font-medium">82/100 hours</span>
                          </div>
                          <Progress value={82} className="h-2" />
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle>Process Fitness</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold">{stats?.processCount || "0"}</div>
                        <p className="text-neutral-500 text-sm mt-1">Techniques practiced</p>
                        
                        <div className="mt-6">
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium">Completion Rate</span>
                            <span className="text-sm font-medium">70%</span>
                          </div>
                          <Progress value={70} className="h-2" />
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle>Yoga Sessions</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold">{stats?.yogaCount || "0"}</div>
                        <p className="text-neutral-500 text-sm mt-1">Sessions completed</p>
                        
                        <div className="mt-6">
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium">Consistency</span>
                            <span className="text-sm font-medium">60%</span>
                          </div>
                          <Progress value={60} className="h-2" />
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
            )}
          </div>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
