import { useQuery } from "@tanstack/react-query";
import { Loader2, Book, Clock, CheckCircle } from "lucide-react";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

export default function ProcessFitnessPage() {
  const { data: processFitness, isLoading } = useQuery({
    queryKey: ["/api/process-fitness"],
  });

  // Process fitness techniques data
  const processFitnessTechniques = [
    {
      id: 1,
      title: "The Pomodoro Technique",
      description: "Work in focused 25-minute intervals with 5-minute breaks",
      icon: <Clock className="h-5 w-5" />,
      steps: [
        "Choose a task to accomplish",
        "Set the timer for 25 minutes",
        "Work on the task until the timer rings",
        "Take a short 5-minute break",
        "After 4 pomodoros, take a longer 15-30 minute break"
      ],
      benefits: "Improves focus, reduces mental fatigue, and increases productivity"
    },
    {
      id: 2,
      title: "Mind Mapping",
      description: "Organize complex information visually",
      icon: <Book className="h-5 w-5" />,
      steps: [
        "Start with a central idea in the middle of a page",
        "Add branches for main sub-topics",
        "Add smaller branches for details",
        "Use colors, images, and symbols for better recall",
        "Review and revise your mind map regularly"
      ],
      benefits: "Enhances understanding, creativity, and memory retention"
    },
    {
      id: 3,
      title: "Feynman Technique",
      description: "Master any concept by teaching it simply",
      icon: <Book className="h-5 w-5" />,
      steps: [
        "Choose a concept to learn",
        "Explain it in simple terms as if teaching a child",
        "Identify gaps in your understanding",
        "Review your source material to fill in the gaps",
        "Simplify your explanation further and use analogies"
      ],
      benefits: "Deepens understanding and exposes knowledge gaps"
    },
    {
      id: 4,
      title: "Active Recall",
      description: "Test yourself to remember information better",
      icon: <CheckCircle className="h-5 w-5" />,
      steps: [
        "Study the material initially",
        "Close your books/notes and try to recall the information",
        "Check your accuracy",
        "Focus on difficult areas",
        "Repeat regularly with increasing time intervals"
      ],
      benefits: "Strengthens memory pathways and improves long-term retention"
    },
    {
      id: 5,
      title: "Time Blocking",
      description: "Schedule specific time blocks for different tasks",
      icon: <Clock className="h-5 w-5" />,
      steps: [
        "List all your tasks and priorities",
        "Estimate the time needed for each task",
        "Assign specific time blocks in your calendar",
        "Include buffer time between blocks",
        "Review and adjust your schedule as needed"
      ],
      benefits: "Reduces procrastination and improves time management"
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 pb-16 md:pb-0">
          <div className="p-6">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-neutral-800">Process Fitness Guides</h2>
              <p className="text-neutral-500">Learn techniques to improve your study process and effectiveness</p>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {processFitnessTechniques.map((technique) => (
                  <Card key={technique.id} className="flex flex-col">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle>{technique.title}</CardTitle>
                          <CardDescription>{technique.description}</CardDescription>
                        </div>
                        <div className="p-2 bg-primary/10 rounded-full">
                          {technique.icon}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-1 flex flex-col">
                      <h4 className="font-medium text-sm mb-2">Steps:</h4>
                      <ol className="list-decimal list-inside text-sm text-neutral-600 mb-4 pl-1 space-y-1">
                        {technique.steps.map((step, index) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ol>
                      
                      <div className="mt-auto">
                        <h4 className="font-medium text-sm mb-1">Benefits:</h4>
                        <p className="text-sm text-neutral-600">{technique.benefits}</p>
                        
                        <div className="mt-4">
                          <div className="flex justify-between mb-1">
                            <span className="text-xs font-medium">Progress</span>
                            <span className="text-xs font-medium">0%</span>
                          </div>
                          <Progress value={0} className="h-1.5" />
                          <Button className="w-full mt-4 bg-primary hover:bg-primary-dark">
                            Start Now
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
