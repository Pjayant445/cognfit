import { useEffect } from "react";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

// Higher-Order Component to protect routes
export function withAuth<P extends object>(Component: React.ComponentType<P>) {
  return function WithAuth(props: P) {
    const { user, isLoading } = useAuth();
    const [_, navigate] = useLocation();

    useEffect(() => {
      if (!isLoading && !user) {
        navigate("/auth");
      }
    }, [isLoading, user, navigate]);

    if (isLoading) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    if (!user) {
      return null; // Will redirect in useEffect
    }

    return <Component {...props} />;
  };
}

// Higher-Order Component for auth pages (login/register)
// Redirects to dashboard if already logged in
export function withAuthOnly<P extends object>(Component: React.ComponentType<P>) {
  return function WithAuthOnly(props: P) {
    const { user, isLoading } = useAuth();
    const [_, navigate] = useLocation();

    useEffect(() => {
      if (!isLoading && user) {
        navigate("/");
      }
    }, [isLoading, user, navigate]);

    if (isLoading) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    return <Component {...props} />;
  };
}