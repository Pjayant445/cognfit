import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Activity, 
  Dumbbell
} from "lucide-react";

export default function MobileNav() {
  const [location] = useLocation();
  
  // Navigation items
  const navItems = [
    {
      title: "Dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
      path: "/",
    },
    {
      title: "Fitness",
      icon: <Dumbbell className="h-5 w-5" />,
      path: "/process-fitness",
    },
    {
      title: "Yoga",
      icon: <span className="material-icons">self_improvement</span>,
      path: "/yoga-sessions",
    },
    {
      title: "Progress",
      icon: <Activity className="h-5 w-5" />,
      path: "/progress",
    },
  ];

  return (
    <nav className="md:hidden bg-white border-t border-neutral-200 fixed bottom-0 left-0 right-0 z-10">
      <div className="flex justify-around">
        {navItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <a
              className={`flex flex-col items-center py-2 ${
                location === item.path
                  ? "text-primary"
                  : "text-neutral-500"
              }`}
            >
              {item.icon}
              <span className="text-xs mt-1">{item.title}</span>
            </a>
          </Link>
        ))}
      </div>
    </nav>
  );
}
