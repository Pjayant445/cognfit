import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, LogOut, User, Settings, HelpCircle } from "lucide-react";

export default function Header() {
  const { user, logoutMutation } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-white border-b border-neutral-200">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <svg
                width="40"
                height="40"
                viewBox="0 0 128 128"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="mr-2"
              >
                <path
                  d="M64 96C81.6731 96 96 81.6731 96 64C96 46.3269 81.6731 32 64 32C46.3269 32 32 46.3269 32 64C32 81.6731 46.3269 96 64 96Z"
                  fill="#F7F9FC"
                />
                <path
                  d="M56 58C56 54.6863 58.6863 52 62 52H66C69.3137 52 72 54.6863 72 58V74C72 77.3137 69.3137 80 66 80H62C58.6863 80 56 77.3137 56 74V58Z"
                  fill="#5D69F4"
                />
                <path
                  d="M52 44C49.7909 44 48 45.7909 48 48C48 50.2091 49.7909 52 52 52H76C78.2091 52 80 50.2091 80 48C80 45.7909 78.2091 44 76 44H52Z"
                  fill="#39D98A"
                />
                <path
                  d="M52 76C49.7909 76 48 77.7909 48 80C48 82.2091 49.7909 84 52 84H76C78.2091 84 80 82.2091 80 80C80 77.7909 78.2091 76 76 76H52Z"
                  fill="#39D98A"
                />
              </svg>
              <h1 className="text-xl font-bold text-neutral-800">CognFit</h1>
            </div>
          </Link>
        </div>
        <div className="flex items-center">
          <div className="hidden md:flex mr-4">
            <Input
              type="text"
              placeholder="Search..."
              className="px-3 py-1 bg-neutral-100 text-sm focus:ring-1 focus:ring-primary"
            />
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="flex items-center focus:outline-none"
              >
                <div className="h-8 w-8 rounded-full bg-neutral-200 mr-2 flex items-center justify-center">
                  {user?.firstName?.charAt(0) || user?.username?.charAt(0) || 'U'}
                </div>
                <span className="hidden md:inline text-sm font-medium">
                  {user?.firstName ? `${user.firstName} ${user.lastName || ''}` : user?.username}
                </span>
                <ChevronDown className="h-4 w-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem className="cursor-pointer">
                <User className="h-4 w-4 mr-2" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer">
                <Settings className="h-4 w-4 mr-2" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer">
                <HelpCircle className="h-4 w-4 mr-2" />
                <span>Help</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                className="cursor-pointer"
                onClick={handleLogout}
              >
                <LogOut className="h-4 w-4 mr-2" />
                <span>Sign out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
