import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  LayoutDashboard, 
  Activity, 
  Dumbbell, 
  Settings,
  LogOut
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Navigation items
  const navItems = [
    {
      title: "Dashboard",
      icon: <LayoutDashboard className="h-5 w-5 mr-3" />,
      path: "/",
    },
    {
      title: "Process Fitness",
      icon: <Dumbbell className="h-5 w-5 mr-3" />,
      path: "/process-fitness",
    },
    {
      title: "Yoga Sessions",
      icon: <div className="mr-3">
              <span className="material-icons">self_improvement</span>
            </div>,
      path: "/yoga-sessions",
    },
    {
      title: "Progress",
      icon: <Activity className="h-5 w-5 mr-3" />,
      path: "/progress",
    },
    {
      title: "Settings",
      icon: <Settings className="h-5 w-5 mr-3" />,
      path: "/settings",
    },
  ];

  return (
    <aside className="hidden md:block w-64 bg-white border-r border-neutral-200">
      <nav className="p-4 h-full">
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.path}>
              <Link href={item.path}>
                <a
                  className={`flex items-center px-4 py-2 rounded-md font-medium ${
                    location === item.path
                      ? "bg-primary/10 text-primary"
                      : "text-neutral-700 hover:bg-neutral-100"
                  }`}
                >
                  {item.icon}
                  {item.title}
                </a>
              </Link>
            </li>
          ))}
        </ul>
        
        {/* Profile summary */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <div className="border-t border-neutral-200 pt-4 mt-4">
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-neutral-200 mr-3 flex items-center justify-center">
                {user?.firstName?.charAt(0) || user?.username?.charAt(0) || 'U'}
              </div>
              <div>
                <p className="text-sm font-medium text-neutral-800">
                  {user?.firstName ? `${user.firstName} ${user.lastName || ''}` : user?.username}
                </p>
                <p className="text-xs text-neutral-500">Student</p>
              </div>
              <button 
                onClick={handleLogout}
                className="ml-auto p-2 text-neutral-500 hover:text-neutral-700"
                title="Logout"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </nav>
    </aside>
  );
}
