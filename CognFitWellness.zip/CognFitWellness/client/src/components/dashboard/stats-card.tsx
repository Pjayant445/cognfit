import { TrendingUp, TrendingDown } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  trend?: number;
  trendLabel?: string;
  trendDirection?: "up" | "down";
}

export default function StatsCard({
  title,
  value,
  icon,
  iconBgColor,
  iconColor,
  trend,
  trendLabel,
  trendDirection = "up",
}: StatsCardProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex justify-between items-start mb-4">
        <div>
          <p className="text-sm text-neutral-500 font-medium">{title}</p>
          <h3 className="text-2xl font-bold text-neutral-800">{value}</h3>
        </div>
        <div className={`p-2 ${iconBgColor} rounded-full`}>
          <span className={`material-icons ${iconColor}`}>{icon}</span>
        </div>
      </div>
      {trend !== undefined && (
        <div className="flex items-center">
          <span 
            className={`text-sm font-medium flex items-center ${
              trendDirection === "up" ? "text-secondary" : "text-status-error"
            }`}
          >
            {trendDirection === "up" ? (
              <TrendingUp className="h-4 w-4 mr-1" />
            ) : (
              <TrendingDown className="h-4 w-4 mr-1" />
            )}
            {trend > 0 ? "+" : ""}{trend}
          </span>
          {trendLabel && <span className="text-sm text-neutral-500 ml-2">{trendLabel}</span>}
        </div>
      )}
    </div>
  );
}
