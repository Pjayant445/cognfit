import { format, formatDistance } from "date-fns";
import { Book, Activity, Dumbbell } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface ActivityProps {
  activity: {
    type: string;
    title: string;
    description: string;
    createdAt?: Date;
    progress?: number;
    completed?: boolean;
  };
}

export default function ActivityItem({ activity }: ActivityProps) {
  const getIcon = () => {
    switch (activity.type) {
      case "study":
        return (
          <div className="p-2 bg-primary/10 rounded-full mr-4">
            <Book className="h-5 w-5 text-primary" />
          </div>
        );
      case "fitness":
        return (
          <div className="p-2 bg-primary/10 rounded-full mr-4">
            <Dumbbell className="h-5 w-5 text-primary" />
          </div>
        );
      case "yoga":
        return (
          <div className="p-2 bg-secondary/10 rounded-full mr-4">
            <span className="material-icons text-secondary">self_improvement</span>
          </div>
        );
      default:
        return (
          <div className="p-2 bg-neutral-100 rounded-full mr-4">
            <Activity className="h-5 w-5 text-neutral-600" />
          </div>
        );
    }
  };

  const getTimeAgo = () => {
    if (!activity.createdAt) return "";
    return formatDistance(new Date(activity.createdAt), new Date(), { addSuffix: true });
  };

  return (
    <li className="p-4 hover:bg-neutral-50">
      <div className="flex items-start">
        {getIcon()}
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div>
              <h4 className="font-medium text-neutral-800">{activity.title}</h4>
              <p className="text-sm text-neutral-500">{activity.description}</p>
            </div>
            <span className="text-xs text-neutral-500">{getTimeAgo()}</span>
          </div>
          
          {activity.progress !== undefined && (
            <div className="mt-2 flex items-center">
              <div className="bg-neutral-200 h-1.5 rounded-full w-full">
                <div 
                  className="bg-primary h-1.5 rounded-full" 
                  style={{ width: `${activity.progress}%` }}
                ></div>
              </div>
              <span className="ml-2 text-xs font-medium text-neutral-600">
                {activity.progress}%
              </span>
            </div>
          )}
        </div>
      </div>
    </li>
  );
}
