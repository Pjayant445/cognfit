import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer } from "recharts";

// Simulate weekly data
const data = [
  { day: "Mon", studyHours: 2.5, studyGoal: 4 },
  { day: "Tue", studyHours: 2, studyGoal: 4 },
  { day: "Wed", studyHours: 4.5, studyGoal: 4 },
  { day: "Thu", studyHours: 3, studyGoal: 4 },
  { day: "Fri", studyHours: 1.5, studyGoal: 4 },
  { day: "Sat", studyHours: 5, studyGoal: 4 },
  { day: "Sun", studyHours: 1, studyGoal: 4 },
];

export default function ProgressChart() {
  return (
    <div className="h-64 flex items-end justify-between">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{ top: 10, right: 10, left: 10, bottom: 10 }}
        >
          <XAxis 
            dataKey="day" 
            axisLine={false}
            tickLine={false}
            tick={{ fontSize: 12, fill: "#718096" }}
          />
          <YAxis 
            hide
            domain={[0, 'dataMax + 1']}
          />
          <Bar
            dataKey="studyGoal"
            fill="#E2E8F0"
            radius={[4, 4, 0, 0]}
            barSize={30}
          />
          <Bar
            dataKey="studyHours"
            fill="#5D69F4"
            radius={[4, 4, 0, 0]}
            barSize={30}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
