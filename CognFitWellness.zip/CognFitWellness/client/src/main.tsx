import { createRoot } from "react-dom/client";
import React from "react";
import "./index.css";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";

// Create a minimal entry point
const AppContainer = React.lazy(() => import("./AppContainer"));

function App() {
  return (
    <React.Suspense fallback={<div>Loading...</div>}>
      <QueryClientProvider client={queryClient}>
        <AppContainer />
        <Toaster />
      </QueryClientProvider>
    </React.Suspense>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
