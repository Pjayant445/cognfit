import React from "react";
import { Route, Switch } from "wouter";
import { AuthProvider } from "./hooks/use-auth";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import ProcessFitnessPage from "@/pages/process-fitness-page";
import YogaSessionsPage from "@/pages/yoga-sessions-page";
import ProgressPage from "@/pages/progress-page";

// These functions will serve as our protected routes by adding the auth check inside each component
const Router = () => (
  <Switch>
    <Route path="/" component={DashboardPage} />
    <Route path="/process-fitness" component={ProcessFitnessPage} />
    <Route path="/yoga-sessions" component={YogaSessionsPage} />
    <Route path="/progress" component={ProgressPage} />
    <Route path="/auth" component={AuthPage} />
    <Route component={NotFound} />
  </Switch>
);

const AppContainer = () => {
  return (
    <AuthProvider>
      <Router />
    </AuthProvider>
  );
};

export default AppContainer;